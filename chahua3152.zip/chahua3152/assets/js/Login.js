//获取页面中的元素
var username=document.getElementById("username");
var password=document.getElementById("password");
var login=document.getElementById("login");
var setInput=document.getElementById("setInput");
//给localStorage加载初始数据
localStorage.username+= "chenzhuozhu:czz970312;";
localStorage.username+="sjaodoa:fajsdlfja;";
//设置个函数判断localStorage中是否有对应的账号密码
function tuust(value) {
    var dta=localStorage.username.split(";");
    for ( i=0;i<dta.length;i++){
        var arrPust=dta[i].split(":");
        if (arrPust[0]==value){
            if (arrPust[1]==password.value){
                return true;
            }
        }
    }
    return false;
}
//给登录按钮添加个判断，先判断用户名和密码框为不为空，并且数据库中有没有对应的数值。
login.addEventListener("click",function () {
    if (username.value==""||password.value==""){
        alert("invalid username or password");
    } else {
        if (tuust(username.value)){
            alert("login successfully");
            username.value="";
            password.value="";
			window.location.href='index.html';
        } else {
            alert("Invalid username or password, try again");
        }
    }
});
//跳转到注册界面
setInput.addEventListener("click",function () {
  location.href="Register.html";
;
})